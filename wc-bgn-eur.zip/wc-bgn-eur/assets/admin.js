/**
 * WC BGN-EUR Admin JavaScript - FIXED VERSION
 */
(function($) {
    'use strict';
    
    const WcBgnEurAdmin = {
        totalProducts: 0,
        currentBatch: 0,
        isProcessing: false,
        
        init: function() {
            this.bindEvents();
        },
        
        bindEvents: function() {
            $('#btn-get-stats').on('click', this.getStats.bind(this));
            $('#btn-backup-db').on('click', this.backupDatabase.bind(this));
            $('#btn-convert-to-eur').on('click', this.startConversion.bind(this, 'bgn_to_eur'));
            $('#btn-convert-to-bgn').on('click', this.startConversion.bind(this, 'eur_to_bgn'));
        },
        
        getStats: function() {
            const $button = $('#btn-get-stats');
            const originalText = $button.text();
            
            $button.prop('disabled', true).text(wcBgnEur.texts.processing);
            
            $.ajax({
                url: wcBgnEur.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'wc_bgn_eur_get_stats',
                    nonce: wcBgnEur.nonce
                },
                success: (response) => {
                    if (response.success) {
                        this.totalProducts = response.data.total_products;
                        $('#total-products').text(this.totalProducts);
                        $('#batch-size').text(response.data.batch_size);
                        
                        $('.wc-bgn-eur-stats').show();
                        // Enable ALL buttons after getting stats
                        $('#btn-convert-to-eur, #btn-convert-to-bgn').prop('disabled', false);
                    } else {
                        this.showError('Failed to get statistics');
                    }
                },
                error: () => {
                    this.showError('Network error occurred');
                },
                complete: () => {
                    $button.prop('disabled', false).text(originalText);
                }
            });
        },
        
        // FIXED BACKUP FUNCTION - REPLACE THE EXISTING ONE
        backupDatabase: function() {
            const $button = $('#btn-backup-db');
            const originalText = $button.text();
            
            $button.prop('disabled', true).text(wcBgnEur.texts.backupInProgress);
            
            $.ajax({
                url: wcBgnEur.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'wc_bgn_eur_backup_db',
                    nonce: wcBgnEur.nonce
                },
                success: (response) => {
                    if (response.success) {
                        // Create a temporary link and trigger download
                        const downloadLink = document.createElement('a');
                        downloadLink.href = response.data.download_url;
                        downloadLink.download = response.data.filename;
                        downloadLink.style.display = 'none';
                        
                        document.body.appendChild(downloadLink);
                        downloadLink.click();
                        document.body.removeChild(downloadLink);
                        
                        // Show success message
                        const timestamp = new Date().toLocaleTimeString();
                        if ($('.progress-log').length) {
                            $('.progress-log').append(`<div>[${timestamp}] ${wcBgnEur.texts.backupComplete}</div>`);
                        }
                        
                        // Show admin notice
                        const $notice = $('<div class="notice notice-success is-dismissible"><p>' + wcBgnEur.texts.backupComplete + '</p></div>');
                        $('.wrap h1').after($notice);
                        
                    } else {
                        this.showError('Backup failed: ' + (response.data || 'Unknown error'));
                    }
                },
                error: (xhr, status, error) => {
                    this.showError('Network error during backup: ' + error);
                },
                complete: () => {
                    $button.prop('disabled', false).text(originalText);
                }
            });
        },
        
        startConversion: function(direction) {
            if (this.isProcessing) {
                return;
            }
            
            const confirmMessage = wcBgnEur.texts.confirm;
            if (!confirm(confirmMessage)) {
                return;
            }
            
            this.isProcessing = true;
            this.currentBatch = 0;
            
            this.showProgress();
            this.updateProgress(0, 'Starting conversion...');
            this.disableButtons();
            
            this.convertBatch(direction);
        },
        
        convertBatch: function(direction) {
            $.ajax({
                url: wcBgnEur.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'wc_bgn_eur_convert',
                    nonce: wcBgnEur.nonce,
                    batch: this.currentBatch,
                    direction: direction
                },
                success: (response) => {
                    if (response.success) {
                        const processed = (this.currentBatch * wcBgnEur.batchSize) + response.data.processed;
                        const percentage = Math.round((processed / this.totalProducts) * 100);
                        
                        this.updateProgress(
                            percentage, 
                            `Processed ${processed} of ${this.totalProducts} products`
                        );
                        
                        if (response.data.has_more) {
                            this.currentBatch = response.data.next_batch;
                            // Continue with next batch
                            setTimeout(() => {
                                this.convertBatch(direction);
                            }, 500); // Small delay to prevent server overload
                        } else {
                            // Conversion completed
                            this.updateProgress(100, wcBgnEur.texts.completed);
                            this.conversionCompleted();
                        }
                    } else {
                        this.showError('Conversion failed: ' + (response.data || 'Unknown error'));
                        this.conversionCompleted();
                    }
                },
                error: (xhr, status, error) => {
                    this.showError('Network error: ' + error);
                    this.conversionCompleted();
                }
            });
        },
        
        conversionCompleted: function() {
            this.isProcessing = false;
            this.enableButtons();
            
            // Refresh stats
            setTimeout(() => {
                this.getStats();
            }, 1000);
        },
        
        showProgress: function() {
            $('.wc-bgn-eur-progress').show();
            $('.progress-fill').css('width', '0%');
            $('.progress-text').text('0%');
            $('.progress-log').empty();
        },
        
        updateProgress: function(percentage, message) {
            $('.progress-fill').css('width', percentage + '%');
            $('.progress-text').text(percentage + '%');
            
            if (message) {
                const timestamp = new Date().toLocaleTimeString();
                $('.progress-log').append(`<div>[${timestamp}] ${message}</div>`);
                
                // Auto-scroll to bottom
                const $log = $('.progress-log');
                $log.scrollTop($log[0].scrollHeight);
            }
        },
        
        disableButtons: function() {
            $('#btn-convert-to-eur, #btn-convert-to-bgn, #btn-get-stats').prop('disabled', true);
        },
        
        enableButtons: function() {
            $('#btn-get-stats').prop('disabled', false);
            if (this.totalProducts > 0) {
                $('#btn-convert-to-eur, #btn-convert-to-bgn').prop('disabled', false);
            }
        },
        
        showError: function(message) {
            const timestamp = new Date().toLocaleTimeString();
            if ($('.progress-log').length) {
                $('.progress-log').append(`<div class="error">[${timestamp}] Error: ${message}</div>`);
            }
            
            // Also show as admin notice
            const $notice = $('<div class="notice notice-error is-dismissible"><p>' + message + '</p></div>');
            $('.wrap h1').after($notice);
        }
    };
    
    // Initialize when document is ready
    $(document).ready(function() {
        WcBgnEurAdmin.init();
    });
    
})(jQuery);