<?php
/**
 * Admin settings page template
 * 
 * @var array $options Plugin options
 */

if (!defined('ABSPATH')) exit;

$plugin = WC_BGN_EUR_Plugin::getInstance();
?>

<div class="wrap wc-bgn-eur-admin">
    <h1><?php esc_html_e('BGN-EUR Price Display Settings', 'wc-bgn-eur'); ?></h1>
    
    <div class="wc-bgn-eur-container">
        <!-- Settings Form -->
        <div class="wc-bgn-eur-settings">
            <form method="post" action="">
                <?php wp_nonce_field(WC_BGN_EUR_Plugin::OPTIONS_KEY . '_group-options'); ?>
                
                <table class="form-table" role="presentation">
                    <tbody>
                        <tr>
                            <th scope="row">
                                <label for="exchange_rate"><?php esc_html_e('Exchange Rate (BGN to EUR)', 'wc-bgn-eur'); ?></label>
                            </th>
                            <td>
                                <input type="number" 
                                       name="<?php echo esc_attr(WC_BGN_EUR_Plugin::OPTIONS_KEY); ?>[exchange_rate]" 
                                       id="exchange_rate"
                                       value="<?php echo esc_attr($plugin->getOption('exchange_rate')); ?>" 
                                       step="0.0001" 
                                       min="0.0001"
                                       class="regular-text" />
                                <p class="description">
                                    <?php esc_html_e('Current official rate: 1 EUR = 1.9558 BGN', 'wc-bgn-eur'); ?>
                                </p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row"><?php esc_html_e('Display Options', 'wc-bgn-eur'); ?></th>
                            <td>
                                <fieldset>
                                    <label>
                                        <input type="checkbox" 
                                               name="<?php echo esc_attr(WC_BGN_EUR_Plugin::OPTIONS_KEY); ?>[display_shop]" 
                                               value="1" 
                                               <?php checked($plugin->getOption('display_shop')); ?> />
                                        <?php esc_html_e('Show on shop and archive pages', 'wc-bgn-eur'); ?>
                                    </label><br>
                                    
                                    <label>
                                        <input type="checkbox" 
                                               name="<?php echo esc_attr(WC_BGN_EUR_Plugin::OPTIONS_KEY); ?>[display_category]" 
                                               value="1" 
                                               <?php checked($plugin->getOption('display_category')); ?> />
                                        <?php esc_html_e('Show on category pages', 'wc-bgn-eur'); ?>
                                    </label><br>
                                    
                                    <label>
                                        <input type="checkbox" 
                                               name="<?php echo esc_attr(WC_BGN_EUR_Plugin::OPTIONS_KEY); ?>[display_single]" 
                                               value="1" 
                                               <?php checked($plugin->getOption('display_single')); ?> />
                                        <?php esc_html_e('Show on single product pages', 'wc-bgn-eur'); ?>
                                    </label>
                                </fieldset>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row">
                                <label for="price_format"><?php esc_html_e('Price Display Format', 'wc-bgn-eur'); ?></label>
                            </th>
                            <td>
                                <select name="<?php echo esc_attr(WC_BGN_EUR_Plugin::OPTIONS_KEY); ?>[price_format]" id="price_format">
                                    <option value="append" <?php selected($plugin->getOption('price_format'), 'append'); ?>>
                                        <?php esc_html_e('Append EUR price (12.50 лв (6.39 €))', 'wc-bgn-eur'); ?>
                                    </option>
                                    <option value="prepend" <?php selected($plugin->getOption('price_format'), 'prepend'); ?>>
                                        <?php esc_html_e('Prepend EUR price ((6.39 €) 12.50 лв)', 'wc-bgn-eur'); ?>
                                    </option>
                                    <option value="replace" <?php selected($plugin->getOption('price_format'), 'replace'); ?>>
                                        <?php esc_html_e('Show only EUR price (6.39 €)', 'wc-bgn-eur'); ?>
                                    </option>
                                </select>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row">
                                <label for="round_decimals"><?php esc_html_e('Decimal Places', 'wc-bgn-eur'); ?></label>
                            </th>
                            <td>
                                <select name="<?php echo esc_attr(WC_BGN_EUR_Plugin::OPTIONS_KEY); ?>[round_decimals]" id="round_decimals">
                                    <?php for ($i = 0; $i <= 4; $i++): ?>
                                        <option value="<?php echo $i; ?>" <?php selected($plugin->getOption('round_decimals'), $i); ?>>
                                            <?php echo $i; ?>
                                        </option>
                                    <?php endfor; ?>
                                </select>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row">
                                <label for="batch_size"><?php esc_html_e('Conversion Batch Size', 'wc-bgn-eur'); ?></label>
                            </th>
                            <td>
                                <select name="<?php echo esc_attr(WC_BGN_EUR_Plugin::OPTIONS_KEY); ?>[batch_size]" id="batch_size">
                                    <?php 
                                    $batch_options = [10, 25, 50, 100, 200, 500];
                                    foreach ($batch_options as $size): 
                                    ?>
                                        <option value="<?php echo $size; ?>" <?php selected($plugin->getOption('batch_size'), $size); ?>>
                                            <?php echo $size; ?> <?php esc_html_e('products', 'wc-bgn-eur'); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="description">
                                    <?php esc_html_e('Number of products to process per batch. Lower values are safer for shared hosting.', 'wc-bgn-eur'); ?>
                                </p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row"><?php esc_html_e('Primary Currency', 'wc-bgn-eur'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" 
                                           name="<?php echo esc_attr(WC_BGN_EUR_Plugin::OPTIONS_KEY); ?>[use_eur_primary]" 
                                           value="1" 
                                           <?php checked($plugin->getOption('use_eur_primary')); ?> />
                                    <?php esc_html_e('Use EUR as primary currency (affects all WooCommerce pricing)', 'wc-bgn-eur'); ?>
                                </label>
                                <p class="description">
                                    <?php esc_html_e('Warning: This will change your shop\'s primary currency to EUR.', 'wc-bgn-eur'); ?>
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
                
                <?php submit_button(); ?>
            </form>
        </div>
        
        <!-- Conversion Tools -->
        <div class="wc-bgn-eur-tools postbox-bgntoeu-conv">
            <div class="postbox ">
                <div class="postbox-header bgntoeu-conv" >
                    <h2 class="hndle"><?php esc_html_e('Price Conversion Tools', 'wc-bgn-eur'); ?></h2>
                </div>
                <div class="inside">
                    <p><?php esc_html_e('Permanently convert all product prices in your database.', 'wc-bgn-eur'); ?></p>
                    
                    <div class="wc-bgn-eur-stats" style="display: none;">
                        <p><strong><?php esc_html_e('Products to process:', 'wc-bgn-eur'); ?></strong> <span id="total-products">-</span></p>
                        <p><strong><?php esc_html_e('Batch size:', 'wc-bgn-eur'); ?></strong> <span id="batch-size">-</span></p>
                    </div>
                    
                    <div class="wc-bgn-eur-actions">
                        <button type="button" id="btn-get-stats" class="button">
                            <?php esc_html_e('Get Statistics', 'wc-bgn-eur'); ?>
                        </button>
                        
                        <button type="button" id="btn-backup-db" class="button" disabled>
                            <?php esc_html_e('Download Backup', 'wc-bgn-eur'); ?>
                        </button>
                        
                        <button type="button" id="btn-convert-to-eur" class="button button-primary" disabled>
                            <?php esc_html_e('Convert BGN - EUR', 'wc-bgn-eur'); ?>
                        </button>
                        
                        <button type="button" id="btn-convert-to-bgn" class="button button-secondary" disabled>
                            <?php esc_html_e('Convert EUR - BGN', 'wc-bgn-eur'); ?>
                        </button>
                    </div>
                    
                    <div class="wc-bgn-eur-progress" style="display: none;">
                        <div class="progress-bar">
                            <div class="progress-fill"></div>
                        </div>
                        <div class="progress-text">0%</div>
                        <div class="progress-log"></div>
                    </div>
                    
                    <div class="wc-bgn-eur-warning">
                        <p><strong><?php esc_html_e('Important:', 'wc-bgn-eur'); ?></strong></p>
                        <ul>
                            <li><?php esc_html_e('Create a safety backup before conversion', 'wc-bgn-eur'); ?></li>
                            <li><?php esc_html_e('This operation is irreversible without a backup', 'wc-bgn-eur'); ?></li>
                            <li><?php esc_html_e('Large catalogs may take several minutes to process', 'wc-bgn-eur'); ?></li>
                            <li><?php esc_html_e('Adjust batch size in settings if you experience timeouts', 'wc-bgn-eur'); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>