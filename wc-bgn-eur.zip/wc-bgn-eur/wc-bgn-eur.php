<?php
/**
 * Plugin Name: WooCommerce BGN-EUR Price Display
 * Plugin URI: https://github.com/no7r3k
 * Description: Display prices in EUR alongside BGN prices with optional permanent conversion
 * Version: 2.0.1
 * Author: no7r3k
 * Author URI: https://github.com/no7r3k
 * Text Domain: wc-bgn-eur
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 * WC requires at least: 5.0
 * WC tested up to: 8.5
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Check if WooCommerce is active
if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    return;
}

// Declare HPOS compatibility
add_action('before_woocommerce_init', function() {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
    }
});

/**
 * Main plugin class
 */
class WC_BGN_EUR_Plugin {
    
    /**
     * Plugin version
     */
    const VERSION = '2.0.1';
    
    /**
     * Plugin slug
     */
    const SLUG = 'wc-bgn-eur';
    
    /**
     * Options key
     */
    const OPTIONS_KEY = 'wc_bgn_eur_settings';
    
    /**
     * Batch size for bulk operations
     */
    const DEFAULT_BATCH_SIZE = 50;
    
    /**
     * Plugin instance
     */
    private static $instance = null;
    
    /**
     * Plugin options
     */
    private $options;
    
    /**
     * Get plugin instance
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->loadOptions();
        $this->initHooks();
    }
    
    /**
     * Load plugin options with defaults
     */
    private function loadOptions() {
        $defaults = [
            'exchange_rate' => 1.9558,
            'display_shop' => true,
            'display_single' => true,
            'display_category' => true,
            'use_eur_primary' => false,
            'price_format' => 'append', // append, prepend, replace
            'round_decimals' => 3,
            'batch_size' => self::DEFAULT_BATCH_SIZE
        ];
        
        $this->options = wp_parse_args(get_option(self::OPTIONS_KEY, []), $defaults);
    }
    
    /**
     * Initialize WordPress hooks
     */
    private function initHooks() {
        // Admin hooks
        add_action('admin_menu', [$this, 'addAdminMenu']);
        add_action('admin_init', [$this, 'registerSettings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueueAdminAssets']);
        
        // AJAX hooks
        add_action('wp_ajax_wc_bgn_eur_convert', [$this, 'ajaxConvertPrices']);
        add_action('wp_ajax_wc_bgn_eur_get_stats', [$this, 'ajaxGetStats']);
        add_action('wp_ajax_wc_bgn_eur_backup_db', [$this, 'ajaxBackupDatabase']);
        
        // Download hook - FIXED: Added missing hook registration
        add_action('wp_ajax_wc_bgn_eur_download_backup', [$this, 'handleBackupDownload']);
        
        // Frontend hooks
        add_filter('woocommerce_get_price_html', [$this, 'modifyPriceDisplay'], 10, 2);
        
        // Currency filters (only if EUR is primary)
        if ($this->options['use_eur_primary']) {
            add_filter('woocommerce_currency', [$this, 'setCurrencyEUR'], 999);
            add_filter('woocommerce_currency_symbol', [$this, 'setCurrencySymbolEUR'], 999, 2);
            add_filter('pre_option_woocommerce_currency', [$this, 'overrideCurrencyOption']);
        }
        
        // Plugin lifecycle hooks
        register_activation_hook(__FILE__, [$this, 'activate']);
        register_deactivation_hook(__FILE__, [$this, 'deactivate']);
    }
    
    /**
     * Add admin menu
     */
    public function addAdminMenu() {
        add_submenu_page(
            'woocommerce',
            __('BGN-EUR Settings', 'wc-bgn-eur'),
            __('BGN-EUR', 'wc-bgn-eur'),
            'manage_woocommerce',
            self::SLUG,
            [$this, 'renderSettingsPage']
        );
    }
    
    /**
     * Register settings
     */
    public function registerSettings() {
        register_setting(
            self::OPTIONS_KEY . '_group',
            self::OPTIONS_KEY,
            [
                'sanitize_callback' => [$this, 'sanitizeSettings'],
                'default' => []
            ]
        );
    }
    
    /**
     * Sanitize settings input
     */
    public function sanitizeSettings($input) {
        $sanitized = [];
        
        // Exchange rate - must be positive number
        $sanitized['exchange_rate'] = max(0.01, floatval($input['exchange_rate'] ?? 1.9558));
        
        // Boolean options
        $sanitized['display_shop'] = !empty($input['display_shop']);
        $sanitized['display_single'] = !empty($input['display_single']);
        $sanitized['display_category'] = !empty($input['display_category']);
        $sanitized['use_eur_primary'] = !empty($input['use_eur_primary']);
        
        // Price format
        $allowed_formats = ['append', 'prepend', 'replace'];
        $sanitized['price_format'] = in_array($input['price_format'] ?? 'append', $allowed_formats) 
            ? $input['price_format'] : 'append';
        
        // Round decimals
        $sanitized['round_decimals'] = max(0, min(4, intval($input['round_decimals'] ?? 2)));
        
        // Batch size
        $sanitized['batch_size'] = max(10, min(500, intval($input['batch_size'] ?? self::DEFAULT_BATCH_SIZE)));
        
        return $sanitized;
    }
    
    /**
     * Enqueue admin assets
     */
    public function enqueueAdminAssets($hook) {
        if (strpos($hook, self::SLUG) === false) {
            return;
        }
        
        wp_enqueue_script(
            self::SLUG . '-admin',
            plugin_dir_url(__FILE__) . 'assets/admin.js',
            ['jquery'],
            self::VERSION,
            true
        );
        
        wp_localize_script(self::SLUG . '-admin', 'wcBgnEur', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wc_bgn_eur_nonce'),
            'batchSize' => $this->options['batch_size'],
            'texts' => [
                'processing' => __('Processing...', 'wc-bgn-eur'),
                'completed' => __('Conversion completed!', 'wc-bgn-eur'),
                'error' => __('An error occurred', 'wc-bgn-eur'),
                'confirm' => __('Are you sure? This will modify all product prices permanently.', 'wc-bgn-eur'),
                'backupInProgress' => __('Creating backup...', 'wc-bgn-eur'),
                'backupComplete' => __('Backup created successfully!', 'wc-bgn-eur')
            ]
        ]);
        
        wp_enqueue_style(
            self::SLUG . '-admin',
            plugin_dir_url(__FILE__) . 'assets/admin.css',
            [],
            self::VERSION
        );
    }
    
    /**
     * Render settings page
     */
    public function renderSettingsPage() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }
        
        // Handle form submission
        if (isset($_POST['submit']) && wp_verify_nonce($_POST['_wpnonce'], self::OPTIONS_KEY . '_group-options')) {
            $this->options = $this->sanitizeSettings($_POST[self::OPTIONS_KEY] ?? []);
            update_option(self::OPTIONS_KEY, $this->options);
            echo '<div class="notice notice-success"><p>' . __('Settings saved.', 'wc-bgn-eur') . '</p></div>';
        }
        
        include plugin_dir_path(__FILE__) . 'templates/admin-page.php';
    }
    
    /**
     * AJAX: Get conversion statistics
     */
    public function ajaxGetStats() {
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'wc_bgn_eur_nonce') || 
            !current_user_can('manage_woocommerce')) {
            wp_die('Security check failed');
        }
        
        global $wpdb;
        
        $total_products = $wpdb->get_var("
            SELECT COUNT(*) 
            FROM {$wpdb->posts} 
            WHERE post_type = 'product' 
            AND post_status = 'publish'
        ");
        
        wp_send_json_success([
            'total_products' => intval($total_products),
            'batch_size' => $this->options['batch_size']
        ]);
    }
    
    /**
     * AJAX: Convert prices
     */
    public function ajaxConvertPrices() {
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'wc_bgn_eur_nonce') || 
            !current_user_can('manage_woocommerce')) {
            wp_die('Security check failed');
        }
        
        $batch = intval($_POST['batch'] ?? 0);
        $direction = sanitize_text_field($_POST['direction'] ?? 'bgn_to_eur');
        $rate = floatval($this->options['exchange_rate']);
        $batch_size = $this->options['batch_size'];
        
        if ($rate <= 0) {
            wp_send_json_error('Invalid exchange rate');
        }
        
        $offset = $batch * $batch_size;
        
        // Get products in batches
        $products = get_posts([
            'post_type' => 'product',
            'post_status' => 'publish',
            'numberposts' => $batch_size,
            'offset' => $offset,
            'fields' => 'ids'
        ]);
        
        $processed = 0;
        
        foreach ($products as $product_id) {
            $product = wc_get_product($product_id);
            if (!$product) continue;
            
            $this->convertProductPrices($product, $rate, $direction);
            $processed++;
        }
        
        wp_send_json_success([
            'processed' => $processed,
            'has_more' => count($products) === $batch_size,
            'next_batch' => $batch + 1
        ]);
    }
    
    /**
     * Convert individual product prices
     */
    private function convertProductPrices($product, $rate, $direction) {
        $multiplier = ($direction === 'bgn_to_eur') ? (1 / $rate) : $rate;
        $decimals = $this->options['round_decimals'];
        
        // Handle different product types
        if ($product->is_type('variable')) {
            $variations = $product->get_children();
            foreach ($variations as $variation_id) {
                $variation = wc_get_product($variation_id);
                if ($variation) {
                    $this->updateProductPrices($variation, $multiplier, $decimals);
                }
            }
        } else {
            $this->updateProductPrices($product, $multiplier, $decimals);
        }
    }
    
    /**
     * Update product prices
     */
    private function updateProductPrices($product, $multiplier, $decimals) {
        $regular_price = $product->get_regular_price();
        $sale_price = $product->get_sale_price();
        
        if ($regular_price !== '') {
            $new_regular = round(floatval($regular_price) * $multiplier, $decimals);
            $product->set_regular_price($new_regular);
        }
        
        if ($sale_price !== '') {
            $new_sale = round(floatval($sale_price) * $multiplier, $decimals);
            $product->set_sale_price($new_sale);
        }
        
        $product->save();
    }
    
    /**
     * Modify price display on frontend
     */
    public function modifyPriceDisplay($price_html, $product) {
        // Skip if EUR is primary currency
        if ($this->options['use_eur_primary']) {
            return $price_html;
        }
        
        // Check if we should display on current page
        if (!$this->shouldDisplayOnCurrentPage()) {
            return $price_html;
        }
        
        $bgn_price = $product->get_price();
        if (!$bgn_price || $bgn_price <= 0) {
            return $price_html;
        }
        
        $eur_price = $this->convertPrice($bgn_price, 'bgn_to_eur');
        $eur_formatted = $this->formatEurPrice($eur_price);
        
        return $this->formatDualPrice($price_html, $eur_formatted);
    }
    
    /**
     * Check if dual price should be displayed on current page
     */
    private function shouldDisplayOnCurrentPage() {
        if ((is_shop() || is_product_tag() || is_search()) && $this->options['display_shop']) {
            return true;
        }
        
        if (is_product_category() && $this->options['display_category']) {
            return true;
        }
        
        if (is_product() && $this->options['display_single']) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Convert price between currencies
     */
    private function convertPrice($price, $direction) {
        $rate = $this->options['exchange_rate'];
        $multiplier = ($direction === 'bgn_to_eur') ? (1 / $rate) : $rate;
        
        return round(floatval($price) * $multiplier, $this->options['round_decimals']);
    }
    
    /**
     * Format EUR price
     */
    private function formatEurPrice($price) {
        return number_format($price, $this->options['round_decimals'], '.', '') . ' €';
    }
    
    /**
     * Format dual price display
     */
    private function formatDualPrice($bgn_html, $eur_formatted) {
        $format = $this->options['price_format'];
        
        switch ($format) {
            case 'prepend':
                return '<span class="wc-bgn-eur-price eur-price">(' . $eur_formatted . ')</span> ' . $bgn_html;
            
            case 'replace':
                return '<span class="wc-bgn-eur-price eur-only">' . $eur_formatted . '</span>';
            
            case 'append':
            default:
                return $bgn_html . ' <span class="wc-bgn-eur-price eur-price">(' . $eur_formatted . ')</span>';
        }
    }
    
    /**
     * AJAX: Create database backup - IMPROVED VERSION
     */
    public function ajaxBackupDatabase() {
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'wc_bgn_eur_nonce') || 
            !current_user_can('manage_woocommerce')) {
            wp_die('Security check failed');
        }
        
        global $wpdb;
        
        try {
            // Create backup data structure instead of SQL file
            $backup_data = [
                'timestamp' => current_time('mysql'),
                'plugin_version' => self::VERSION,
                'products' => [],
                'variations' => []
            ];
            
            // Get all products with their price meta
            $products = $wpdb->get_results("
                SELECT p.ID, p.post_title, p.post_type,
                       GROUP_CONCAT(CONCAT(pm.meta_key, ':', pm.meta_value) SEPARATOR '|') as price_meta
                FROM {$wpdb->posts} p
                LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id 
                WHERE p.post_type IN ('product', 'product_variation')
                AND p.post_status = 'publish'
                AND pm.meta_key IN ('_regular_price', '_sale_price', '_price')
                GROUP BY p.ID
                ORDER BY p.post_type, p.ID
            ", ARRAY_A);
            
            foreach ($products as $product) {
                $price_data = [];
                if (!empty($product['price_meta'])) {
                    $meta_pairs = explode('|', $product['price_meta']);
                    foreach ($meta_pairs as $pair) {
                        if (strpos($pair, ':') !== false) {
                            list($key, $value) = explode(':', $pair, 2);
                            $price_data[$key] = $value;
                        }
                    }
                }
                
                $item = [
                    'id' => $product['ID'],
                    'title' => $product['post_title'],
                    'prices' => $price_data
                ];
                
                if ($product['post_type'] === 'product') {
                    $backup_data['products'][] = $item;
                } else {
                    $backup_data['variations'][] = $item;
                }
            }
            
            // Create JSON backup instead of SQL
            $backup_content = json_encode($backup_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            
            if ($backup_content === false) {
                throw new Exception('Failed to create backup data');
            }
            
            // Create filename with timestamp
            $filename = 'wc-bgn-eur-backup-' . date('Y-m-d-H-i-s') . '.json';
            
            // Save to uploads directory with better path handling
            $upload_dir = wp_upload_dir();
            $backup_dir = $upload_dir['basedir'] . '/wc-bgn-eur-backups';
            
            // Create backup directory if it doesn't exist
            if (!file_exists($backup_dir)) {
                wp_mkdir_p($backup_dir);
                // Add .htaccess to protect backups
                file_put_contents($backup_dir . '/.htaccess', "Deny from all\n");
            }
            
            $file_path = $backup_dir . '/' . $filename;
            
            if (file_put_contents($file_path, $backup_content) === false) {
                throw new Exception('Failed to create backup file');
            }
            
            // Store backup info for cleanup later
            $backup_info = get_option('wc_bgn_eur_backups', []);
            $backup_info[] = [
                'filename' => $filename,
                'filepath' => $file_path,
                'created' => time(),
                'size' => filesize($file_path),
                'products_count' => count($backup_data['products']),
                'variations_count' => count($backup_data['variations'])
            ];
            
            // Keep only last 10 backups
            if (count($backup_info) > 10) {
                $old_backup = array_shift($backup_info);
                if (file_exists($old_backup['filepath'])) {
                    unlink($old_backup['filepath']);
                }
            }
            
            update_option('wc_bgn_eur_backups', $backup_info);
            
            // Create secure download token
            $download_token = wp_create_nonce('download_' . $filename . '_' . time());
            set_transient('wc_bgn_eur_download_' . $download_token, $filename, 300); // 5 minutes
            
            wp_send_json_success([
                'filename' => $filename,
                'download_token' => $download_token,
                'products_count' => count($backup_data['products']),
                'variations_count' => count($backup_data['variations']),
                'file_size' => size_format(filesize($file_path))
            ]);
            
        } catch (Exception $e) {
            wp_send_json_error('Backup failed: ' . $e->getMessage());
        }
    }
    
    /**
     * Handle backup file download - COMPLETELY REWRITTEN
     */
    public function handleBackupDownload() {
        // Verify nonce and permissions
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Insufficient permissions');
        }
        
        $token = sanitize_text_field($_GET['token'] ?? '');
        if (empty($token)) {
            wp_die('Invalid download token');
        }
        
        // Get filename from transient
        $filename = get_transient('wc_bgn_eur_download_' . $token);
        if ($filename === false) {
            wp_die('Download token expired or invalid');
        }
        
        // Clean transient
        delete_transient('wc_bgn_eur_download_' . $token);
        
        // Validate filename
        if (!preg_match('/^wc-bgn-eur-backup-\d{4}-\d{2}-\d{2}-\d{2}-\d{2}-\d{2}\.json$/', $filename)) {
            wp_die('Invalid backup filename');
        }
        
        $upload_dir = wp_upload_dir();
        $file_path = $upload_dir['basedir'] . '/wc-bgn-eur-backups/' . $filename;
        
        if (!file_exists($file_path) || !is_readable($file_path)) {
            wp_die('Backup file not found');
        }
        
        // Clear any output that might have been sent
        if (ob_get_level()) {
            ob_end_clean();
        }
        
        // Set proper headers for download
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($filename) . '"');
        header('Content-Length: ' . filesize($file_path));
        header('Cache-Control: no-cache, no-store, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');
        
        // Output file contents
        readfile($file_path);
        
        // Clean exit
        exit;
    }
    
    /**
     * Override WooCommerce currency option
     */
    public function overrideCurrencyOption($value) {
        return 'EUR';
    }
    
    /**
     * Set currency to EUR
     */
    public function setCurrencyEUR($currency) {
        return 'EUR';
    }
    
    /**
     * Set currency symbol to EUR
     */
    public function setCurrencySymbolEUR($symbol, $currency) {
        return $currency === 'EUR' ? '€' : $symbol;
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Create default options if they don't exist
        if (!get_option(self::OPTIONS_KEY)) {
            $this->loadOptions();
            update_option(self::OPTIONS_KEY, $this->options);
        }
        
        // Clear any caches
        if (function_exists('wp_cache_flush')) {
            wp_cache_flush();
        }
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Clean up old backup files
        $backup_info = get_option('wc_bgn_eur_backups', []);
        foreach ($backup_info as $backup) {
            if (file_exists($backup['filepath'])) {
                unlink($backup['filepath']);
            }
        }
        delete_option('wc_bgn_eur_backups');
        
        // Clear any caches
        if (function_exists('wp_cache_flush')) {
            wp_cache_flush();
        }
    }
    
    /**
     * Get option value
     */
    public function getOption($key, $default = null) {
        return $this->options[$key] ?? $default;
    }
}

// Initialize plugin
WC_BGN_EUR_Plugin::getInstance();